Please only submit feature suggestions or bug reports if you believe something is broken. Please do not submit support requests and general help questions.

If you enjoy Beautiful Jekyll, please consider supporting the theme! https://beautifuljekyll.com/plans/
